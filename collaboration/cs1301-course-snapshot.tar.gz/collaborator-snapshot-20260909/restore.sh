#!/bin/sh
set -eu

snapshot_dir=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
project_dir=${1:-$(pwd)}
cd "$project_dir"

if [ ! -f compose.yaml ]; then
  echo "Run this from the cs1301-platform repository, or pass its path as the first argument." >&2
  exit 1
fi

docker compose stop backend celery >/dev/null 2>&1 || true
docker compose up -d postgres redis
docker compose exec -T postgres dropdb -U cs1301 --if-exists cs1301
docker compose exec -T postgres createdb -U cs1301 cs1301
docker compose exec -T postgres pg_restore -U cs1301 -d cs1301 --no-owner --no-privileges < "$snapshot_dir/course.pgcustom"
docker compose up -d backend
docker compose exec -T backend tar -C /app/private-media -xzf - < "$snapshot_dir/private-media.tar.gz"
docker compose up -d --build

printf '\nCourse restored. Open http://localhost:5173 and choose Open local workspace.\n'
