CS 1301 collaborator snapshot

1. Clone or update the cs1301-platform repository.
2. Put the shared .env file in the repository root.
3. Install and start Docker Desktop.
4. Extract this snapshot outside the repository.
5. From the repository root, run:

   /path/to/collaborator-snapshot-20260909/restore.sh

6. Open http://localhost:5173 and choose "Open local workspace".

Django superuser access is not required. Restoring replaces the local cs1301
Docker database on that computer. The snapshot contains course configuration and
private course assets, but excludes student records, workspaces, submissions,
progress, quiz attempts, execution jobs, and browser sessions.
